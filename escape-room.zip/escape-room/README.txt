Escape Room (offline)

Como jogar offline
1) Extraia este arquivo .zip para uma pasta da sua preferência (ex.: Área de Trabalho/escape-room).
2) Abra o arquivo index.html no seu navegador (Chrome, Edge, Firefox, Safari).
3) Clique nos objetos da cena para interagir (planta → gaveta → quadro/cofre → porta).
4) Para recomeçar, clique em "Reiniciar" no topo da página.

Requisitos
- Navegador moderno; não é necessário instalar nada.

Objetivo do jogo
- Encontre o código do cofre e a chave da porta para escapar do estúdio.

Dica
- O relógio marca 03:15. O código do cofre é a hora sem os dois pontos.

Créditos
- Feito com HTML, CSS e JavaScript.